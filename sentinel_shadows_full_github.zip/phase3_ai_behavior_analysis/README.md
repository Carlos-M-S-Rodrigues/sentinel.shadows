# Sentinel Shadows – Phase 3: Behavioral AI Detection

This phase introduces AI-driven analysis of attacker behavior patterns and adaptive trap logic.

## Key Features

- Azure Function AI engine analyzing honeypot logs
- Azure Sentinel behavioral detection rules (KQL)
- Adaptive logic to escalate or deploy traps based on behavior
- Optional OpenAI integration

## Deployment

Deploy using Azure CLI:

```bash
az deployment group create --resource-group <your-rg> --template-file main.bicep
```

Ensure you have enabled Microsoft Defender and Sentinel on your workspace.
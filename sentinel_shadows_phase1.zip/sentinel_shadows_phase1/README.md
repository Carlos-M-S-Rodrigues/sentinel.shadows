# Sentinel Shadows – Phase 1

This Bicep deployment sets up the MVP version of Sentinel Shadows:
- SSH honeypot VM
- Fake web admin login page
- Azure Log Analytics integration
- Alert rules and notifications

## Deployment

1. Clone this repo
2. Open Azure Cloud Shell or use VS Code with Bicep
3. Run:

```bash
az deployment group create --resource-group <your-rg> --template-file main.bicep
```

## Customize Parameters

Update `parameters.json` if needed.

## Notes

- Default VMs use minimal specs to reduce cost.
- Logs can be queried in Log Analytics Workspace.
# Sentinel Shadows – Phase 2

This deployment adds smarter, more interactive honeypots to Sentinel Shadows:

- Fake MySQL database VM
- Canary token links
- Shared file drive with trap files

## Deploy Instructions

Run from Azure CLI or Cloud Shell:

```bash
az deployment group create --resource-group <your-rg> --template-file main.bicep
```

## Components

- `fake-db.bicep`: A VM running MySQL with fake user data.
- `canary-links.bicep`: Triggers alerts when fake secrets/URLs are accessed.
- `shared-drive.bicep`: Azure Files share with canary documents.